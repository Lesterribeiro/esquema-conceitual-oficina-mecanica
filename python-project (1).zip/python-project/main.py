import os

arquivos = {
    "sql/script_oficina.sql": """CREATE TABLE CLIENTE (
  idCliente INT PRIMARY KEY,
  nome VARCHAR(100),
  cpf_cnpj VARCHAR(18),
  telefone VARCHAR(20),
  endereco VARCHAR(150)
);

CREATE TABLE VEICULO (
  idVeiculo INT PRIMARY KEY,
  placa VARCHAR(10),
  modelo VARCHAR(50),
  marca VARCHAR(50),
  ano INT,
  idCliente INT
);

CREATE TABLE EQUIPE (
  idEquipe INT PRIMARY KEY,
  nomeEquipe VARCHAR(50),
  especialidadePrincipal VARCHAR(50)
);

CREATE TABLE MECANICO (
  idMecanico INT PRIMARY KEY,
  codigo VARCHAR(20),
  nome VARCHAR(100),
  endereco VARCHAR(150),
  especialidade VARCHAR(50),
  idEquipe INT
);

CREATE TABLE ORDEM_SERVICO (
  idOS INT PRIMARY KEY,
  numeroOS VARCHAR(20),
  dataEmissao DATE,
  dataEntregaPrevista DATE,
  dataConclusao DATE,
  valorTotal DECIMAL(10,2),
  status VARCHAR(30),
  autorizadaCliente BOOLEAN,
  idVeiculo INT,
  idEquipe INT
);

CREATE TABLE TABELA_SERVICO (
  idServico INT PRIMARY KEY,
  descricaoServico VARCHAR(100),
  valorMaoDeObra DECIMAL(10,2)
);

CREATE TABLE PECA (
  idPeca INT PRIMARY KEY,
  nomePeca VARCHAR(100),
  valorUnitario DECIMAL(10,2),
  estoque INT
);

CREATE TABLE OS_SERVICO (
  idOS INT,
  idServico INT,
  quantidade INT,
  subtotalServico DECIMAL(10,2),
  PRIMARY KEY (idOS, idServico)
);

CREATE TABLE OS_PECA (
  idOS INT,
  idPeca INT,
  quantidade INT,
  subtotalPeca DECIMAL(10,2),
  PRIMARY KEY (idOS, idPeca)
);
""",
    "README.md": """# 🔧 Modelagem Conceitual e Lógica – Sistema de Oficina Mecânica

Projeto de arquitetura de banco de dados relacional desenvolvido para o controle e gerenciamento de execução de **Ordens de Serviço (OS)** em uma oficina mecânica, estruturado a partir da narrativa de negócios proposta no desafio da DIO.

---

## Diagrama Entidade-Relacionamento (DER)

![Diagrama Entidade Relacionamento Oficina](./diagrams/DER-Oficina-Mecanica.png)

---

## 1. Regras de Negócio e Entidades Mapeadas

O modelo relacional foi construído para refletir fielmente o fluxo operacional de uma oficina:

* **Clientes e Veículos (`1:N`):** Um cliente pode cadastrar múltiplos veículos para revisão periódica ou conserto.
* **Equipes e Mecânicos (`1:N`):** Cada veículo é designado a uma equipe específica, composta por mecânicos identificados por código, nome, endereço e especialidade. A mesma equipe responsável pela avaliação executa os serviços.
* **Ordem de Serviço (`OS`):** Documento central contendo número, data de emissão, previsão de entrega, data de conclusão, status e o registro booleano de autorização explícita do cliente antes da execução.
* **Composição de Valores (`N:N`):** O valor total da OS é calculado dinamicamente pela soma dos serviços executados (consultados em uma tabela de referência de mão de obra) e das peças utilizadas no reparo, resolvidos pelas tabelas associativas `OS_SERVICO` e `OS_PECA`.

---

## 2. Organização do Repositório

```text
/
├── diagrams/
│   ├── DER-Oficina-Mecanica.png      # Exportação visual do esquema em alta resolução
│   └── DER-Oficina-Mecanica.drawio   # Arquivo fonte editável do diagrams.net
├── sql/
│   └── script_oficina.sql            # Script DDL de criação das tabelas relacionais
└── README.md                         # Documentação técnica do projeto
```
"""
}

for caminho, conteudo in arquivos.items():
    pasta = os.path.dirname(caminho)
    if pasta and not os.path.exists(pasta):
        os.makedirs(pasta)
    with open(caminho, "w", encoding="utf-8") as f:
        f.write(conteudo)
    print(f"Criado: {caminho}")
